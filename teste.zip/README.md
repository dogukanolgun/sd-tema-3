testele se afla in folderele ".in", iar rezultatele se afla in, ".ref".
Codurile sursa sunt 1.c 2.c 3.c 4.c. Celelalte de tip play/playground sunt algoritmi partiali.
Fisierele de tip teste/teste_problema sunt exemplele din cerinta.
